#ifndef EMPLOYES_H_INCLUDED
#define EMPLOYES_H_INCLUDED



int user_type(char ur[], char ps[]);



#endif
