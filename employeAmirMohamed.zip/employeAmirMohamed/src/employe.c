#ifdef HAVE_CONGIG_H
# include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "employe.h"
#include <gtk/gtk.h>
enum
{
   
  ID,
  NOM,
  PRENOM,
  DATE,
  ADRESSE,
  SEXE,
  NATIONALITE,
  COLUMNS,
};

void ajouter_employe(employe e)
{
FILE* f;
f=fopen("employe.txt","a+");
  if(f!=NULL)
   {
   fprintf(f,"%s %s %s %s %s %s %s \n",e.id,e.nom,e.prenom,e.dt_debut,e.adresse,e.sexe,e.nation);
   }
fclose(f);
}

void Modifier_employe(employe ep)
{
employe e;
FILE *f;
FILE *g;

f=fopen("employe.txt","a+");
g=fopen("employe2.txt","a+");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s ",e.id,e.nom,e.prenom,e.dt_debut,e.adresse,e.sexe,e.nation)!=EOF)
{ if (strcmp(e.id,ep.id)==0)
	fprintf(g,"%s %s %s %s %s %s %s  \n",ep.id,ep.nom,ep.prenom,ep.dt_debut,ep.adresse,ep.sexe,ep.nation);
else
	fprintf(g,"%s %s %s %s %s %s %s  \n",e.id,e.nom,e.prenom,e.dt_debut,e.adresse,e.sexe,e.nation);
}
fclose(f);
fclose(g);
remove("employe.txt");
rename("employe2.txt","employe.txt");

}}

void Supprimer_employe (employe e)
{
employe ep;	
FILE *f;
FILE *g;

f=fopen("employe.txt","a+");
g=fopen("employe2.txt","a+");
if (f!=NULL )
    {
	while (fscanf(f,"%s %s %s %s %s %s %s  \n",ep.id,ep.nom,ep.prenom,ep.dt_debut,ep.adresse,ep.sexe,ep.nation)!=EOF)
	{	if (strcmp(e.id,ep.id)!=0)	
			{fprintf(g,"%s %s %s %s %s %s %s  \n",ep.id,ep.nom,ep.prenom,ep.dt_debut,ep.adresse,ep.sexe,ep.nation);
			}
	}

	fclose(f);
	fclose(g);
	remove("employe.txt");
	rename("employe2.txt","employe.txt");

   }
}

void afficher_employe(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

{

char id[30];
char nom[30];
char prenom[30];
char dt_debut[30];
char adresse[30];
char sexe[30];
char nation[30];
store=NULL;

FILE  *f;

store=gtk_tree_view_get_model(liste);

  if(store==NULL)
  {
   
   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("id ",renderer,"text",ID,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);	

   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("nom ",renderer,"text",NOM,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("prenom    ",renderer,"text",PRENOM,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("dt_debut ",renderer,"text",DATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("adresse ",renderer,"text",ADRESSE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("sexe ",renderer,"text",SEXE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("nation ",renderer,"text",NATIONALITE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

   f=fopen("employe.txt","r");

     if(f==NULL)
{ return;}
else
        {
         f=fopen("employe.txt","a+");
         while(fscanf(f,"%s %s %s %s %s %s %s",id,nom,prenom,dt_debut,adresse,sexe,nation)!=EOF)
          {
           gtk_list_store_append(store,&iter);
           gtk_list_store_set(store,&iter,ID,id,NOM,nom,PRENOM,prenom,DATE,dt_debut,ADRESSE,adresse,SEXE,sexe,NATIONALITE,nation,-1);
          }
        }
   fclose(f);

   gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
   g_object_unref(store);  

   }
}}


