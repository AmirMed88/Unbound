#include <gtk/gtk.h>


void
on_modifieremp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Ajouteremp_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_afficheremp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimeremp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5_retouraff_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retoursupp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourmodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button9_modifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button9_modifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourmodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton6_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
