#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "employe.h" 

int x;
int y;
void
on_modifieremp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *ajout_emp,*modif_emp;
GtkWidget *combo;
	FILE *f;
	char id[30];
ajout_emp=lookup_widget(objet,"ajout emp");
gtk_widget_destroy(ajout_emp);
modif_emp=create_modif_emp();
combo=lookup_widget(modif_emp,"combobox4");
	f=fopen("employe.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s \n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
gtk_widget_show(modif_emp);}

void
on_Ajouteremp_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
employe e;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input8,*nation;	
GtkWidget *ajout_emp;


ajout_emp=lookup_widget(objet_graphique,"ajout emp");	
input1=lookup_widget(objet_graphique,"entry1");
input2=lookup_widget(objet_graphique,"entry2");
input3=lookup_widget(objet_graphique,"entry3");
input4=lookup_widget(objet_graphique,"entry4");
input5=lookup_widget(objet_graphique,"entry5");
nation=lookup_widget(objet_graphique,"combobox1");



strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.dt_debut,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(e.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));

strcpy(e.nation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nation)));
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(input3)));

if(x==0)
{strcpy(e.sexe,"Homme");}
else
if(x==1)
{strcpy(e.sexe,"Femme");}
ajouter_employe(e);
}


void
on_afficheremp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajout_emp;
GtkWidget *affiche_emp;
GtkWidget *treeview1;


ajout_emp=lookup_widget(objet,"ajout emp");
gtk_widget_destroy(ajout_emp);
affiche_emp=lookup_widget(objet,"Affiche_emp");
affiche_emp=create_Affiche_emp();
gtk_widget_show(affiche_emp);
treeview1=lookup_widget(affiche_emp,"treeview1");
afficher_employe(treeview1);
}


void
on_supprimeremp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *ajout_emp,*supprim_emp;
GtkWidget *combo;
	FILE *f;
	char id[30];
ajout_emp=lookup_widget(objet,"ajout emp");
gtk_widget_destroy(ajout_emp);
supprim_emp=create_supprimer_emp();
combo=lookup_widget(supprim_emp,"combobox2_supp");
	f=fopen("employe.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s \n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
gtk_widget_show(supprim_emp);
}



void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{		GtkTreeIter iter;
		gchar* id;
		gchar* nom;
		gchar* prenom;
		gchar* dt_debut;
		gchar* adresse;
		gchar* sexe;
		gchar* nation;
		employe e;
		int id1;
		
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path)) {
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&prenom,3,&dt_debut,4,&adresse,5,&sexe,6,&nation,-1);
strcpy(e.id,id);
strcpy(e.nom,nom);
strcpy(e.prenom,prenom);
strcpy(e.dt_debut,dt_debut);
strcpy(e.adresse,adresse);
strcpy(e.sexe,sexe);
strcpy(e.nation,nation);

afficher_employe(treeview);

}}


void
on_button5_retouraff_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *affiche_emp,*ajout_emp; 
affiche_emp=lookup_widget(objet,"Affiche_emp");
gtk_widget_destroy(affiche_emp);
ajout_emp=create_ajout_emp();
gtk_widget_show(ajout_emp);}

void
on_button7_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{	employe e;
GtkWidget *input;
input= lookup_widget(objet,"combobox2_supp");
strcpy(e.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
Supprimer_employe(e);
}


void
on_retoursupp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
{GtkWidget *supprim_emp,*ajout_emp; 
supprim_emp=lookup_widget(objet,"supprimer_emp");
gtk_widget_destroy(supprim_emp);
ajout_emp=create_ajout_emp();
gtk_widget_show(ajout_emp);}
}

void
on_button9_modifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
employe e;
GtkWidget *modif_emp; 	
GtkWidget *id,*nom,*prenom,*dt_debut,*adresse,*sexe,*nation;
modif_emp=lookup_widget(objet,"modif_emp");
id= lookup_widget(objet,"combobox4");
nom= lookup_widget(objet,"entry6");
prenom= lookup_widget(objet,"entry7");
dt_debut=lookup_widget(objet,"entry8");
adresse=lookup_widget(objet,"entry9");
sexe=lookup_widget(objet,"entry10");
nation=lookup_widget(objet,"combobox3");

strcpy(e.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.dt_debut,gtk_entry_get_text(GTK_ENTRY(dt_debut)));
strcpy(e.adresse,gtk_entry_get_text(GTK_ENTRY(adresse)));
strcpy(e.sexe,gtk_entry_get_text(GTK_ENTRY(sexe)));
strcpy(e.nation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nation)));



Modifier_employe(e);
}


void
on_retourmodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *modif_emp,*ajout_emp;
modif_emp=lookup_widget(objet,"modif_emp");
gtk_widget_destroy(modif_emp);
ajout_emp=create_ajout_emp();
gtk_widget_show(ajout_emp);}


void
on_radiobutton6_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=0;
}
}

void
on_radiobutton5_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}
