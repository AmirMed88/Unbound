int exist_cap(tabCapteurs*e,int n,int id);
int remplire_numero(tabCapteurs*e,int aa,char*fich);
float calculer_max(int id,int aa,char*fich);
float calculer_min(int id,int aa,char*fich);
int remplire_id_capt(char*fich,int aa,float seuil_minA,float seuil_minB,float seuil_maxA,float seuil_maxB,int*capt);
