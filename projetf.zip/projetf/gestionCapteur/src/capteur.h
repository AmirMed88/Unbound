void ajouter_capteur(capteur cap);
int exist_capteur(char*id);
void supprimer_capteur(char*id);
capteur trouver_capteur(char*id);
void modifier_capteur(capteur c);
afficher_single_capteur(GtkWidget* treeview1,capteur cap);
void treeViewCapteur(GtkWidget* treeview1,char*l);

